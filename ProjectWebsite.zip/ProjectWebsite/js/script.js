// مثال بسيط للتحقق من كلمة المرور في صفحة التسجيل
document.addEventListener("DOMContentLoaded", () => {
  const registerForm = document.getElementById("registerForm");
  if (registerForm) {
    registerForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const password = registerForm.querySelectorAll("input[type='password']")[0].value;
      const confirm = registerForm.querySelectorAll("input[type='password']")[1].value;

      if (password !== confirm) {
        alert("Passwords do not match!");
      } else {
        alert("Registration successful!");
      }
    });
  }

  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", function (e) {
      e.preventDefault();
      alert("Login attempt!");
    });
  }

  const forgotForm = document.getElementById("forgotForm");
  if (forgotForm) {
    forgotForm.addEventListener("submit", function (e) {
      e.preventDefault();
      alert("Password reset link sent!");
    });
  }
});
